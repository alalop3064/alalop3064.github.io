'''earthEyes demonstrates PIL.Image.paste()
Unpublished work (c)2013 Project Lead The Way
CSE Activity 1.3.7 PIL API
Version 9/10/2013 '''

import PIL
import matplotlib.pyplot as plt
import os.path              




#start pikachu figure code 

directory = os.path.dirname(os.path.abspath(__file__))  # Open the files in the same directory as the Python script
pika_file = os.path.join(directory, 'pikachu.jpg') #Make jpg file equal to pike_file
pika_img = PIL.Image.open(pika_file)  #open pike file with PIL. Make it equal to pika_img
fig, axes = plt.subplots(1, 2)
axes[0].imshow(pika_img, interpolation='none') #full pikachu
axes[1].imshow(pika_img, interpolation='none')#pikachu face
axes[1].set_xticks(range(1050, 1410, 100))
axes[1].set_xlim(183, 584) 
axes[1].set_ylim(545, 160)

#fig.show()
#end pika

#start slowpoke figure code
slow = plt.imread('Slowpoke.png') #open slowpoke png. make it equal to slow
fig4, axes4 = plt.subplots(1, 1)#set up plots
axes4.imshow(slow)#show slow
axes4.axis('off')#turn of axes
height = len(slow)#define height
width = len(slow[0])#define width
for r in range(height):
    for c in range(width):
        if 3<sum(slow[r][c])<3.5:
            slow[r][c]=[1,.85,.14,1] #change color of pixels with certain brightness
#fig4.show()
fig4.savefig('slow.png',transparent=True) #save the file as slow.png. make the background transparent.


slow_img = PIL.Image.open('slow.png')#open slow.png with PIL. make it equal to slow_img
mask_big = slow_img.resize((950,700)) #resize file. rename to mask_big
fig2, ax2 = plt.subplots(1, 1)
ax2.imshow(mask_big)#display mask_big
ax2.axis('off')
height = 640
width = 1000
#fig2.show()


#end slowpoke

#start file paste
pika_img.paste(mask_big, (-100, 0), mask=mask_big) #paste mask_big (slowpoke resized file) onto pikachu image. -100 and 0  are coordinates
fig3, axes3 = plt.subplots(1, 4)#set up 4 plots
pika_og=plt.imread('pikachu.jpg')
slow_og=plt.imread('slowpoke.png')
axes3[0].imshow(pika_og, interpolation='none')
axes3[1].imshow(slow_og,interpolation='none')
axes3[2].imshow(pika_img, interpolation='none')
axes3[3].imshow(pika_img, interpolation='none')
axes3[3].set_xlim(170, 590)
axes3[3].set_ylim(570, 160)

fig3.show()