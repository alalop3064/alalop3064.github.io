listA=[1,2,3,4,5]
listB=[4,3,6,5,10,76,1]
listC=[12,13,12,12,16,14]
listF=[1,5,3,3,8,9,5,5]
def sort_list(list):
    count=0
    string_list=""
    while count< len(list):
        if count<len(list)-2:
            string_list+=str(list[count])+", "
        elif count<len(list)-1:
            if not count<3:
                string_list+=str(list[count])+", and "
            else:
                string_list+=str(list[count])+" and "
        else:
             string_list+=str(list[count])
        count+=1
    return string_list

def get_mean(list):
    total=0
    for n in list:
        total+=n
    total = float(total)
    length = float(len(list))
    mean = total/length
    sorted_list=sorted(list)
    string_list=sort_list(sorted_list)
    return str(total)+ "The mean of "+ string_list + " is " + str(mean)+"."

def get_median(list):
    sorted_list=sorted(list)
    length=len(list)
    a=0
    b=0
    median=0
    if length%2==0:
        a=sorted_list[length/2]
        b=sorted_list[(length/2)-1]
        median=(a+b)/2.0
    else:
        median=sorted_list[(length-1)/2]    
    string_list=sort_list(sorted_list)
    return "The median of "+ string_list + " is " + str(median)+"."

def get_mode(list):
    sorted_list=sorted(list)
    length=len(list)
    new_list=[]
    mode_list=[]
    mode_count=0
    count=0
    for i in list:
        new_list.append(0)
    while count< length:
        for i in list:
            if list[count]==i:
                new_list[count]=new_list[count]+1
        count+=1
    for i in new_list:
        if i>mode_count:
            mode_count=i
    count=0
    while count< length:
        if new_list[count]==mode_count:
            if list[count] not in mode_list:
                mode_list.append(list[count])
        count+=1      
    string_list=sort_list(sorted_list)
    string_mode=sort_list(mode_list)
    return "The mode of "+ string_list + " is " + string_mode+"."
            
        
def get_range(list):
    sorted_list=sorted(list)
    length=len(list)
    a=sorted_list[length-1]
    b=sorted_list[0]
    range_=a-b
    string_list=sort_list(sorted_list)
    return "The range of "+ string_list + " is " + str(range_)+"."
def get_MMMR(list):
    mean=get_mean(list)
    median=get_median(list)
    mode=get_mode(list)
    range_=get_range(list)
    return mean,median,mode,range_
    