import random
import sys
def r(x):
    return raw_input(x)
def u(x):
    return x.upper()

#
#
#Function outside() is what happens when you go outside. It will be used multiple times.
def attack1(o,options):
    o=''
    r('You have decided to attack it.')
    print('***What do you do?***\nA) Use the meter stick\nB) Use the scissors\nC) Use the pen...?')
    while u(o) not in options:
        o= r('Choose: ')
    if u(o)=='A':
        r('You wack the zombie with the meter stick right on the face')
        r('The meter stick breaks in two!')
        r('You were exactly a meter away from the zombie giving you time to run!')
        r('You continue on your path')
        r('You are on the right track to winning')
    if u(o)=='B':
        r('You charge at it and stab it in the eye.')
        r('It lets out a scream of pain, but now that you are closer to it, it has a hold of you.')
        r('It holds on to you and takes a bite off your face.')
        r('You can guess what happens next...')
        r('.\n.\n.')
        r('GAME OVER')
        o=''
    if u(o)=='C':
        r('That was a dumb choice.')
        r('You should just leave because that choice was so dumb')
        r('But i\'ll be nice and run the story through')
        r('You charge at it and stab it in the eye.')
        r('It lets out a scream of pain, but now that you are closer to it, it has a hold of you.')
        r('It holds on to you and takes a bite off your face.')
        r('You can guess what happens next...')
        r('.\n.\n.')
        r('GAME OVER')
        o=''
def attack2(o,options):
    o=''
    r('You have decided to attack it.')
    print('***What do you do?***\nA) Use the scissors\nB) Use the pen...?')
    while u(o) not in options:
        o= r('Choose: ')
    if u(o)=='A':
        r('You charge at it and stab it in the eye.')
        r('It lets out a scream of pain, but now that you are closer to it, it has a hold of you.')
        r('It holds on to you and takes a bite off your face.')
        r('You can guess what happens next...')
        r('.\n.\n.')
        r('If only you have a meter stick')
        r('GAME OVER')
        o=''
    if u(o)=='B':
        r('That was a dumb choice.')
        r('You should just leave because that choice was so dumb')
        r('But i\'ll be nice and run the story through')
        r('You charge at it and stab it in the eye.')
        r('It lets out a scream of pain, but now that you are closer to it, it has a hold of you.')
        r('It holds on to you and takes a bite off your face.')
        r('You can guess what happens next...')
        r('.\n.\n.')
        r('If only you have a meter stick')
        r('GAME OVER')
        o=''
        
#
#
#

def outside1(y1,c1,o1,options11,options21,d1):
    
    r('Before you leave you get a meter stick, some scissors, and a pen.')
    r('You turn around for one last goodbye and then walk out the door.')
    r('It is darker than you expected, you feel a rush of fear, but then you get yourself together.')
    r('Your main mission is to get food for everyone else, but just as you are about to head towards the cafeteria, you hear someone scream help from somewhere distant.')
    
    print('***What do you do?***\nA)Go to the cafeteria, thats my main mission\nB)Go try and help the person in need')
    o1=''
    while u(o1) not in options11:
        o1= r('Choose: ')
    
    if u(o1)=='A':
        
        r('You choose to continue to walk towards the cafeteria.')
        r('You take what you believe is the safest path, the stairways in front of the 5000 building, closest to the cafeteria.')
        r('You peer over the end of the building and see them for the first time.')
        r('They twitch as they walk, there\'s something definitely wrong in their heads')
        r('They turn to sound, but their other senses must be impaired because they have trouble walking')
        r('You continue towards the stairway and start to go down them.')
        r('That\'s where you encounter one for the very first time')
        r('It\'s on the second floor, feeding on somebody. It\'s gnawing through the persons flesh like a piece of pie.')
        
        r('You look a little closer and see that the person being eaten is '+d1+'!')
        print('***What do you do?***\nA) Go around it... Very quietly\nB) Attack it!\nC) Turn around quietly and go another route.')
        o1=''
        while u(o1) not in options21:
            o1= r('Choose: ')
        if u(o1)=='C':
            r('You turn around, but you notice there is a zombie coming from that way too!')
            r('You go back to the zombie at the stairs')
            print('***What do you do?***\nA) Go around it... Very quietly\nB) Attack it!\n')
            o1=''
            while u(o1) not in options21:
                o1= r('Choose: ')
            s='True'
        else:
            s='True'
        if s=='True':
            if u(o1)=='A':
                r('You try and go around the zombie...')
                r('You go around safely, so you continue to walk.')
                r('Just as you get past it, you step on an empty bag of chips.')
                r('The zombie turns to look at you and lunges at your feet.')
                r('You fall down and try to get up, but you are too slow.')
                r('You suffer a slow painful death as the zombie eats your guts.')
                r('.\n.\n.')
                r('GAME OVER')
            if u(o1)=='B':
                attack1(o1,options21)
                o1=''
    if u(o1)=='B':
        r('The cry for help was coming from the 6000 building, all the way at the back of the school.')
        r('You walk over to the person calling for help. It\'s... '+d1+'!!')
        r('"'+y1+'! Please help me, I am injured!"')
        r('You notice they have a bite on their leg.')
        r('"It\'s just a little bite, I feel totally fine, please, are you guys still at the classroom? Can you help me walk over there?"')
        print('***What do you do?***\nA)Help '+d1+' get to the classroom\nB)Leave '+d1+', they can manage on their own.')
        o1=''
        while u(o1) not in options11:
            o1= r('Choose: ')
        if u(o1)=='A':
            r('You decided to help '+d1+'. You let them hold on to you and you guys start walking back to the classroom')
            r('"Thank you so much '+y1+', I shouldn\'t have left the classroom')
            r('I should\'ve stay and-", you hear a sound behind you guys.')
            r('You turn around and see a zombie coming up off the stairs. It\'s gaining on you guys.')
            r('You turn the corner and see two more zombies heading your way!')
            r('You decide to book it. Maybe you can run past the zombie behind you.')
            r(d1+' notices your plan. Just as you are about to run, '+d1+' holds on to you tightly and you both fall on the floor')
            r('"If I\'m going to die, you\'re going to die with me," '+d1+' whispers in your ear')
            r('The three zombies get to you and eat you up.')
            r('.\n.\n.')
            r('GAME OVER')
            o1=''
        if u(o1)=='B':
            r('You turn around and pretend that '+d1+' didn\'t exist')
            r('"Hey! Where are you going! HEY! COME BACK!"')
            r('The noise '+d1+' made attracted zombies')
            r('All of a sudden you find yourself trapped in a hoard of zombies.')
            print('***What do you do?***\nA) Fight through the zombies, die with your pride!\nB) Screw that, jump off the third floor, die with your dignity!')
            o1=''
            while u(o1) not in options11:
                o1= r('Choose: ')
            if u(o1)=='A':
                r('You smile as the zombies shread you to peices and eat your limbs off.')
                r('Pain is just a thought. You die a peaceful death.')
                r('.\n.\n.')
                r('GAME OVER')
                o1=''
            if u(o1)=='B':
                r('Just as you are about to jump off, a zombie grabs on to the back of your shirt.')
                r('You couldn\'t have died a more gruesome or painful death.')
                r('You felt every ounce of pain as they munch and devoured your very body.')
                r('.\n.\n.')
                r('GAME OVER')
                o1=''
            
                
#
#
#
def outside2(y1,c1,o1,options11,options21,b1,d1):
    r('Before you leave you get some scissors and a pen.')
    r('A meter stick would be useful but '+b1+' took the last one')
    r('You turn around for one last goodbye and then walk out the door.')
    r('It is darker than you expected, you feel a rush of fear, but then you get yourself together.')
    r('Your main mission is to get food for everyone else, but just as you are about to head towards the cafeteria, you hear someone scream help from somewhere distant.')
    print('***What do you do?***\nA)Go to the cafeteria, thats my main mission\nB)Go try and help the person in need, maybe it\'s '+b1+'!')
    o1=''
    while u(o1) not in options11:
        o1= r('Choose: ')
    
    if u(o1)=='A':
        
        r('You choose to continue to walk towards the cafeteria.')
        r('You take what you believe is the safest path, the stairways in front of the 5000 building, closest to the cafeteria.')
        r('You peer over the end of the building and see them for the first time.')
        r('They twitch as they walk, there\'s something definitely wrong in their heads')
        r('They turn to sound, but their other senses must be impaired because they have trouble walking')
        r('You continue towards the stairway and start to go down them.')
        r('That\'s where you encounter one for the very first time')
        r('It\'s on the second floor, feeding on somebody. It\'s gnawing through the persons flesh like a piece of pie.')
        
        r('You look a little closer and see that it is '+d1+'!')
        print('***What do you do?***\nA) Go around it... Very quietly\nB) Attack it!\nC) Turn around quietly and go another route.')
        o1=''
        while u(o1) not in options21:
            o1= r('Choose: ')
        if u(o1)=='C':
            r('You turn around, but you notice there is a zombie coming from that way too!')
            r('You go back to the zombie at the stairs')
            print('***What do you do?***\nA) Go around it... Very quietly\nB) Attack it!\n')
            o1=''
            while u(o1) not in options21:
                o1= r('Choose: ')
            s='True'
        else:
            s='True'
        if s=='True':
            if u(o1)=='A':
                r('You try and go around the zombie...')
                r('You go around safely, so you continue to walk.')
                r('Just as you get past it, you step on an empty bag of chips.')
                r('The zombie turns to look at you and lunges at your feet.')
                r('You fall down and try to get up, but you are too slow.')
                r('You suffer a slow painful death as the zombie eats your guts.')
                r('.\n.\n.')
                r('GAME OVER')
            if u(o1)=='B':
                r('You have decided to attack it.')
                attack2(o1,options21)
                o1=''
    if u(o1)=='B':
        r('The cry for help was coming from the 6000 building, all the way at the back of the school.')
        r('You walk over to the person calling for help. It\'s... '+d1+'!!')
        r('"'+y1+'! Please help me, I am injured!"')
        r('You notice they have a bite on their leg.')
        r('"It\'s just a little bite, I feel totally fine, please, are you guys still at the classroom? Can you help me walk over there?"')
        print('***What do you do?***\nA)Help '+d1+' get to the classroom\nB)That\'s not '+b1+'! Leave '+d1+', they can manage on their own.')
        o1=''
        while u(o1) not in options11:
            o1= r('Choose: ')
        if u(o1)=='A':
            r('You decided to help '+d1+'. You let them hold on to you and you guys start walking back to the classroom')
            r('"Thank you so much '+y1+', I shouldn\'t have left the classroom')
            r('I should\'ve stay and-", you hear a sound behind you guys.')
            r('You turn around and see a zombie coming up off the stairs. It\'s gaining on you guys.')
            r('You turn the corner and see two more zombies heading your way!')
            r('You decide to book it. Maybe you can run past the zombie behind you.')
            r(d1+' notices your plan. Just as you are about to run, '+d1+' holds on to you tightly and you both fall on the floor')
            r('"If I\'m going to die, you\'re going to die with me," '+d1+' whispers in your ear')
            r('The three zombies get to you and eat you up.')
            r('.\n.\n.')
            r('GAME OVER')
            o1=''
        if u(o1)=='B':
            r('You turn around and pretend that '+d1+' didn\'t exist')
            r('"Hey! Where are you going! HEY! COME BACK!"')
            r('The noise '+d1+' made attracted zombies')
            r('All of a sudden you find yourself trapped in a hoard of zombies.')
            print('***What do you do?***\nA) Fight through the zombies, die with your pride!\nB) Screw that, jump off the third floor, die with your dignity!')
            o1=''
            while u(o1) not in options11:
                o1= r('Choose: ')
            if u(o1)=='A':
                r('You smile as the zombies shread you to peices and eat your limbs off.')
                r('Pain is just a thought. You die a peaceful death.')
                r('.\n.\n.')
                r('GAME OVER')
                o1=''
            if u(o1)=='B':
                r('Just as you are about to jump off, a zombie grabs on to the back of your shirt.')
                r('You couldn\'t have died a more gruesome or painful death.')
                r('You felt every ounce of pain as they munch and devoured your very body.')
                r('.\n.\n.')
                r('GAME OVER')
                o1=''
#
#
#
def zombie_apocalypse():
    #Variables
    #
    #
    pe='(Press Enter...)'
    y=''
    c=['','','','']
    countname=0
    countc=0
    classroom = ['Alan', 'Fabrizio', 'Jovannie', 'Anthony', 'Ashley', 'Abi', 'Sergio', 'Jose', 'Brandon', 'Bryan', 'Jorge', 'Esteban', 'Mrs. Barroso']
    places=['1st','2nd','3rd','4th']
    options1=['A','B']
    options2=['A','B','C']
    o=''
    s=''
    d=''
    b=''
    n=0
    #weapons=['meter stick', 'scissors', 'pen']
    #
    #
    #End Variables
    r('Welcome to Alan and Fabrizio\'s Zombie Apocalypse game! You will be transported to a world where anything is a possibility. We hope you enjoy! \n'+pe)
    
    
    for i in classroom:
        if countname == 12:
            print classroom[countname],
        else:   
            print classroom[countname]+',' , 
       
            
        countname+=1 
    countname=0
    
    for i in classroom:
            classroom[countname]= u(classroom[countname])
            countname+=1
    
    while y not in classroom:   
        y = r('Choose your own name from the list above: ')
        y=u(y)
        while y not in classroom:
            y= r('Try again: ')
            y=u(y)
    classroom.remove(y);
    
    print('Choose who you would like to take this journey with.')

    for i in c:
        if countc < 4:
            while c[countc] not in classroom:
                c[countc]= r('Choose your '+places[countc]+ ' companion: ')
                c[countc]= u(c[countc])
                while c[countc] not in classroom:
                        c[countc]= r('Try Again: ')
                        c[countc]= u(c[countc])
            classroom.remove(c[countc]);
            countc+= 1 
    d=random.choice(classroom)
    classroom.remove(d)
   
    '''
    
    #
    #
    #Troubleshooting
    #
    y='ALAN'
    c=['ABI','FABRIZIO','SERGIO','BRANDON']
    d='BRYAN'
    print c
    print classroom
    for i in classroom:
            classroom[countname]= u(classroom[countname])
            countname+=1
    for i in c:
        classroom.remove(i)
    #
    #
    #
    '''
    s=''
    countc=0
   
    r('Great! Now lets begin our journey.')
    if y != 'MRS. BARROSO':
        r('Year 2017... You\'re in Mrs. Barroso\'s class... It\'s getting pretty boring.\n'+pe)
    else:
        r('Year 2017... You\'re teaching CSP. It\'s getting pretty boring.\n'+pe)
    
    r('The intercom goes off *beep* "This is a lock-down. Do not leave the rooms under any circumstance.')
    r('I repeat this is a- AHHH!! HELP ME!!!"')
    r('.\n.\n.')
    r('*gorey sounds* "AHH!"')
    r('.\n.\n.')
    r('*low growl*')
    r('.\n.\n.')
    r('*beep* The Intercom is cut off.\n'+pe)
    
    r('You turn to look at ' +c[0]+ '. Both of you guys are confused on whether it is a joke or not.')
    
    if y != 'MRS. BARROSO':
        r('"Uh... okay you guys let\'s stay inside.", says Mrs. Barroso.')
   
    else:
        s=r('What do you tell your students?: ')
        while len(s)<10:
            s=r('That probably sucked, try again: ')
        r(c[3]+ ' rolled their eyes at you. But you don\'t care.')
    
      
    print('*** What do you do?*** \nA) Call someone\nB) Remain Calm \nC) PANIC')
    
    while u(o) not in options2:
        o= r('Choose: ')
    if u(o) == 'A':
        r('The phone towers are down!\n'+pe)
    if u(o) == 'B':
        r('You have decided to wait.\n'+pe)    
    if u(o) == 'C':
        r('As you try and run outside. You are immediately pulled back in by '+c[0]+' and tied down with someones sweater.\n'+pe)
    o='' 
    
    r('.\n.\n.')
    r('It has been three hours and you have not heard anything from anyone.')
    r('You have heard horrific screams of terror and cries of desperation.')
    r('Everyone shoots looks at each other, their face filled with concern, for you are all struck with fear.')
    r('.\n.\n.')
    r('It has been two more hours. The room is dead quite until out of no where '+d+' says, "Screw this, I\'m going home,')
    r('I\'m not going to stay here waiting for someone to save MY life."')
    
    s=''
    countc=0
    for i in c:
        if countc < len(c)-1:
            s+=c[countc]+', '
        else:
            s+='and '+c[countc]
        countc+=1
    
    r(d+' procedes to then walk out the room. You look around the room and everyone else also start to leave.')
    r('The only people who didn\'t leave were '+s+' .')
    r('.\n.\n.')
    r('It\'s starting to get dark outside. You have been talking for a while with '+c[0]+' and you get interrupted.')
    r('You hear a knock at the door. *boom boom boom boom*')
    r('"Help me!! Please someone open the door!"')
    
    print('*** What do you do?***\nA) They are human too. Let them in.\nB) Screw that. They can stay outside')
    while u(o) not in options1:
        o= r('Choose: ')
    
    #STORY SPLITS!
    #
    #
    #FAB'S STORY
    
    if u(o) == 'A':
        r('A student with ragged clothes limps quickly into the classroom. He was obviously wounded.')
        r('He walks by you, and you being the nosy person you are, you look at his wounds. It is clearly a bite mark!')
        print('*** What do you do?***\nA) Point out his wound to the group.\nB) Keep quiet. No one needs to know.')
        o=''
        while u(o) not in options1:
            o=r('Choose: ')
        if u(o) == 'A':
            r(c[3]+' decides to try to treat the wound. In the process, '+c[3]+' gets infected!!!!')
            r('They began showing signs of becoming zombies!!!!')
            print('*** What do you do?***\nA)Kill them both.\nB)Let them live.')
            o=''
            while u(o) not in options1:
                o=r('Choose: ')
                if u(o) == 'A':
                    r('You kill them, but their bodies began to smell extremely bad. The stench attracts a swarm of zombies!')
                    r('They begin to break down the doors and you are engulfed in a crowd of zombies....')
                    r('You die, GAME OVER')
                    sys.exit('Play again soon!')
                if u(o) == 'B':
                    r('They are alive, great! Or is it?')
                    r('They begin showing zombie-like traits')
                    r('First, they lose intelligence, they are brain dead. Then, they begin to attempt to take bites out of '+c[2]+'.')
                    r('...')
                    r('They are completely zombies now! The door is jammed and you are trapped.')
                    r('Everone gets eaten by the two zombies. First, it was '+c[0]+', and after the zombies finished with '+c[0]+', they looked at you. You tried running but you were cornered.')
                    r('You died because '+c[3]+' ate you, GAME OVER!')
                    sys.exit('Play again soon!')
        if u(o) == 'B':
            r('So you stay quiet, but you begin to notice he is converting into a zombie.')
            r('Out of nowhere, he lunges at you and knocks you down!')
            r('He is attempting to eat you alive and you are holding him off, but you can\'t hold him off forever')
            print ('***What do you do?***\nA)Scream for help from your companions\nB)Accept your fate, you\'re a dead man')
            o=''
            while u(o) not in options1:
                o=r('Choose: ')
                if u(o) == 'A':
                    r('"Help! Help!"')
                    r('Everyone is too scared to help you...')
                    r('You are tired out and the zombie eats you. GAME OVER')
                    sys.exit('Play again soon!')
                if u(o) == 'B':
                    r('You have accepted your fate.')
                    r('You know your classmates won\'t help you')
                    r('*BOOM* People in Hazmat suits have arrived!')
                    r('They get rid of the zombie and save your life!')
                    r('The people in hazmat suits offer to take you back to their underground bunker where it\'s safe')
                    print('***What do you do?***\nA)Go with them, they saved your life!\nB)Stay in the class, you don\'t even know these people.')
                    o=''
                    while u(o) not in options1:
                        o=r('Choose: ')
                        if u(o) == 'A':
                            r('You decided to follow them to their safety bunker.')
                            r('On your way there, you run into a hoard of zombies.')
                            r('They block your way!')
                            print('***What do you do?***\nA)Run for your life!\nB)Run towards the zombies, you\'re doomed anyway')
                            o=''
                            while u(o) not in options1:
                                o=r('Choose: ')
                                if u(o) == 'A':
                                    r('You are running, but the zombies are chasing you')
                                    r('You should\'ve tried harder in PE because these zombies are catching up to you quite quickly.')
                                    r('You ran into a dead end...')
                                    r('You\'re cornered....AAAHHHH!!!!')
                                    r('You died, GAME OVER')
                                    sys.exit('Play again soon!')
                                if u(o) == 'B':
                                    r('Are you dumb?')
                                    r('You die, GAME OVER')
                                    sys.exit('Play again soon!')
                        if u(o) == 'B':
                            r('You remain in the class, who needs those fools anyway.')
                            r('Fast forward to midnight...')
                            r('Food and water are scarce, you\'re dehydrated to the point where your lips are chapped.')
                            print('***What do you do?***\nA)Go get water from the water fountain outside the class.\nB)Accept your fate, you\'re doomed anyway.')
                            o=''
                            while u(o) not in options1:
                                o=r('Choose: ')
                                if u(o) == 'A':
                                    r('You know where the fountain is, so you blast out the door and make a run for it.')
                                    r('As you went through the door, you ran into a hoard of zombies who quickly grabbed hold of you.')
                                    r('You were eaten by zombies. GAME OVER')
                                    sys.exit('Play again soon!')
                                if u(o) == 'B':
                                    r('You have reached zen. Death no longer scares you.')
                                    r('As you sit there, absorbing your surroundings, the people in hazmat suits break through the door *BOOM*')
                                    r('They have brought supplies! It includes water, food, and sleeping bags!')
                                    r('You notice something odd about one of the people in hazmat suits...')
                                    r('His suit is punctured and he is clearly ill!')
                                    print('***What do you do?***\nA)Warn the others, they need to know!\nB)Let him stay for these are his final days.')
                                    o=''
                                    while u(o) not in options1:
                                        o=r('Choose: ')
                                        if u(o) == 'A':
                                            r('"Are you crazy?", says '+c[2]+'. "They are our heroes, they can\'t be sick."')
                                            r('Blinded by their heroism, they don\'t realize that the man is ill.')
                                            r('They proceed to kick you out for they now consider you a "weak link."')
                                            print('***What do you do?***\nA)Run home, these people are CRAZY!\nB)Run towards the crowd of zombies nearby, what you got to lose.')
                                            o=''
                                            while u(o) not in options1:
                                                o=r('Choose: ')
                                                if u(o) == 'A':
                                                    r('There you are running with the destination in mind, home.')
                                                    r('Out of nowhere, a zombie jumps out of a bush and tackles you down')
                                                    r('You get eaten and die...GAME OVER')
                                                    sys.exit('Play again soon!')
                                                if u(o) == 'B':
                                                    r('The zombies are startled from your actions and flee.')
                                                    r('The zombies left a man there, and you go up to him to see if he\'s okay')
                                                    r('He begins to ramble on about something.')
                                                    print('***What do you do?***\nA)Pay attention, this could be important.\nB)Nod your head and pretend you\'re listening')
                                                    o=''
                                                    while u(o) not in options1:
                                                        o=r('Choose: ')
                                                        if u(o) == 'A':
                                                            r('You discover he is a scientist and his objective was to bring the serum that cured the zombie illness.')
                                                            r('He puts out his hand so you could take the sreum to where it needs to go.')
                                                            r('Mission: SAVE EARTH')
                                                            r('Excited to save human kind, you race up the stairs to give  the serum to the people in hazmat suits.')
                                                            r('You trip on your way up and drop it serum...')
                                                            r('*CLING* It shattered and the serum is lost forever. GAME OVER')
                                                            sys.exit('Play again soon!')
                                                        if u(o) == 'B':
                                                            r('You no longer hear him for his voice is drowned out by the daydream you\'re having.')
                                                            r('He hands you a serum and says, "Good luck."')
                                                            r('You walk back to the classroom and you hand the serum to the people in hazmat suits.')
                                                            r('It\'s the cure!')
                                                            r('Everyone celebrates, but as everyone is jumping up and down in joy, the serum slips from their hand..')
                                                            r('Time has slowed, you see the serum falling in the air.')
                                                            print('***What do you do?***\nA)CATCH IT!!!!!\nB)Let it fall, it\'s going to quickly anyway.')
                                                            o=''
                                                            while u(o) not in options1:
                                                                o=r('Choose: ')
                                                                if u(o) == 'A':
                                                                    r('You took too long to decide...')
                                                                    r('The serum has shattered on the floor, and you have doomed the human race...GAME OVER')
                                                                    sys.exit('Play again soon!')
                                                                if u(o) == 'B':
                                                                    r('Just your luck, the person who dropped it happened to catch it in time.')
                                                                    r('With the cure at hand, you need to go with the people in hazmat suits to their lab to get it worldwide.')
                                                                    r('...')
                                                                    r('You make it to their lab, and you see a huge globe in the middle of the room.')
                                                                    r('The globe gives the information on how many are infected, you and your companions are the only ones not infected worldwide.')
                                                                    r('*evil laughter from the people in hazmat suits*')
                                                                    r('Hazmat 1: "We are going to be gods!"')
                                                                    r('Hazmat 2: "I can\'t believe a side effect of this cure is to be brainwashed and be completely submissive. Everyone will listen to us!"')
                                                                    r('Hazmat 1&2: "MWUAHAHAHAHA!!!!"')
                                                                    print('***What do you do?***\nA)Let the world become enslaved, it\'s not your problem\nB)Destroy the cure! An enslaved community isn\t right!')
                                                                    o=''
                                                                    while u(o) not in options1:
                                                                        o=r('Choose: ')
                                                                        if u(o) == 'A':
                                                                            r('CONGRATS! You have saved the human race!')
                                                                            r('But they are enslaved...')
                                                                            r('So you really just created a future of enslaved humans for generations to come.')
                                                                            r('You doomed the human race. GAME OVER!!!!')
                                                                            sys.exit('Play again soon!')
                                                                        if u(o) == 'B':
                                                                            r('You have ensured the extincion of the human race.')
                                                                            r('On the bright side, they won\'t be enslaved.')
                                                                            r('YOU WIN! CONGRATS!!!!')
                                                                            sys.exit('Play again soon!')
                                                                            
                                        if u(o) == 'B':
                                            r('HE HAS TURNED INTO A ZOMBIE!!!!')
                                            print('***What do you do?***\nA)Chain him up, it\'s the right thing to do\nB)Kill him, it\'s the only thing that will keep you all safe')
                                            o=''
                                            while u(o) not in options1:
                                                o=r('Choose: ')
                                                if u(o) == 'A':
                                                    r('He is all chained up, what a relief')
                                                    r('Fastforward a few hours, everyone is asleep...')
                                                    r('*CLING* The chain didn\'t work!')
                                                    r('In your sleep, he has eaten you all...GAME OVER')
                                                    sys.exit('Play again soon!')
                                                if u(o) == 'B':
                                                    r('Good riddance,')
                                                    r('The body is quite smelly...it attracts a hoard of zombies!')
                                                    r('They break in the classroom and eat you all....GAME OVER')
                                                    sys.exit('Play again soon!')
                                                    
                                     
                            
                    
                    
    
    #
    #
    #ALAN'S STORY    
    if u(o) == 'B':
        
        r('They keep knocking and yelling for about 3 more minutes. You hear a cry of desperation and then hear them walk away.')
        r('It\'s quiet for a while, then you hear them banging on the door next door.')
        r('.\n.\n.')
        r('The outside has been quiet for a while. It\'s dark now.')
        r('"I\'m getting pretty hungry", says '+c[1]+'.')
        r('"Yeah, me too...", you reply.')
        r('"Do you think it is safe to go out for food?", says '+c[2]+'.')
        r('"Yes, someone should go... I mean we are all hungry", says '+c[3]+'.')
        
        print('***What do you do?***\nA)Be a hero. You go.\nB)Screw that, send '+c[3]+'.\nC)Pick someone at random.')       
        
        o=''
        while u(o) not in options2:
            o= r('Choose: ')
        if u(o) == 'A':
            
            r('You feel compelled to go outside and scavenge for food.')
            r('"I\'m going out", you tell everyone. "I\'m going to bring us food."')
            r('Everyone agrees to let you go out.')
            countc=0
            s=''
            for i in c:
                if countc < len(c)-1:
                    s+=c[countc]+', '
                
                else:
                    s+='and '+c[countc]
                countc+=1
            r(s+' all wish you the best of luck.')
            outside1(y,c,o,options1,options2,d)
        if u(o) == 'B':
            b=c[3]
            c.remove(c[3])
            s=''
            countc=0
            for i in c:
                if countc<2:
                    s+=c[countc]+', '
                else:
                    s+= 'and '+c[countc]
                countc+=1   
            r('You, '+s+' all wish '+b+' the best of luck.')
            r(b+' takes a meter stick, some scissors, and a pen with them.')
            r( '"I\'ll be back in time for supper!", says '+b+' with a nervous chuckle.')
            r('Then, '+b+' walks out the door...')
            
            r('.\n.\n.')
            r('It has been 4 hours. You have not heard a thing from '+b+'. None of you guys have ever been so hungry in your entire lives.')
            s=random.choice(c)
            r('"I dont think '+b+' is coming back...", says '+s+'.')
            r('You feel compelled to go outside and scavenge for food now that '+b+' is gone.')
            r('"I\'m going out", you tell everyone. "I\'m going to bring us food."')
            s=random.choice(c)
            r('"You can\'t leave!", says '+s+', "how do we know you will be coming back? God knows what happened to '+b+'."')
            r('"If I don\'t go then we will starve to death!" you reply. "Please, you must let me go."')
            r('Finally, you convinced everyone to let you go.')
            outside2(y,c,o,options1,options2,b,d)
            
            
        if u(o)=='C':
            n=random.randint(0,5)
            if n==0:
                b=y
            else:
                b= random.choice(c)
            r('Everyone wrote their name on a small piece of paper and put in a cup.')
            s= random.choice(c)
            r(s+' had the honors to pull out a name.')
            r('The chosen one was...')
            r('.\n.\n.')
            if y == b:
                r('You!')
                s=''
                countc=0
                for i in c:
                    if countc < len(c)-1:
                        s+=c[countc]+', '
                    else:
                        s+='and '+c[countc]
                    countc+=1
                r(s+' all wish you the best of luck.')
                
                outside1(y,c,o,options1,options2,d)
            else:
                c.remove(b)
                r(b+'!')
                s=''
                countc=0
                for i in c:
                    if countc<3:
                        s+= c[countc]+', '
                    else:
                        s+= 'and '+c[countc]
                    countc+=1 
                r('You, '+s+' all wish '+b+' the best of luck.')
                r(b+' takes a meter stick, some scissors, and a pen with them.')
                r( '"I\'ll be back in time for supper!", says '+b+' with a nervous chuckle.')
                r('Then, '+b+' walks out the door...')
            
                r('.\n.\n.')
                r('It has been 4 hours. You have not heard a thing from '+b+'. None of you guys have ever been so hungry in your entire lives.')
                s=random.choice(c)
                r('"I dont think '+b+' is coming back...", says '+s+'.')
                r('You feel compelled to go outside and scavenge for food now that '+b+' is gone.')
                r('"I\'m going out", you tell everyone. "I\'m going to bring us food."')
                s=random.choice(c)
                r('"You can\'t leave!", says '+s+', "how do we know you will be coming back? God knows what happened to '+b+'."')
                r('"If I don\'t go then we will starve to death!" you reply. "Please, you must let me go."')
                r('Finally, you convinced everyone to let you go.')
                outside2(y,c,o,options1,options2,b,d)
                
            
            
    